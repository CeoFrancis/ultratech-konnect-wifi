import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home, Building2, Users, Smartphone } from "lucide-react";

const Services = () => {
  const services = [
    {
      icon: Home,
      title: "Home Wi-Fi",
      description: "Reliable high-speed internet for your family. Stream, browse, and work from home seamlessly.",
      features: ["Unlimited data", "24/7 support", "Easy installation", "M-Pesa payments"],
      price: "Starting from KSh 2,500/month",
      color: "text-blue-600"
    },
    {
      icon: Building2,
      title: "Business Solutions",
      description: "Scalable internet solutions for businesses of all sizes. Boost productivity with dedicated support.",
      features: ["Dedicated bandwidth", "Priority support", "Backup solutions", "Custom packages"],
      price: "Starting from KSh 5,000/month",
      color: "text-green-600"
    },
    {
      icon: Users,
      title: "Hotspot Reseller",
      description: "Start your own internet business. Become a UltratechKonnect reseller and earn monthly commissions.",
      features: ["Low startup cost", "Training provided", "Marketing support", "Monthly commissions"],
      price: "Initial investment KSh 15,000",
      color: "text-purple-600"
    }
  ];

  return (
    <section className="py-16 bg-gradient-subtle">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose the perfect internet solution for your needs. From home connections to business packages, 
            we have you covered.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="relative overflow-hidden group hover:shadow-elegant transition-all duration-300 border-2 hover:border-primary/20">
              <CardHeader className="relative z-10">
                <div className={`inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-primary mb-4 ${service.color}`}>
                  <service.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <CardTitle className="text-xl font-bold">{service.title}</CardTitle>
                <CardDescription className="text-muted-foreground">
                  {service.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-2 text-sm">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="pt-4 border-t border-border">
                  <p className="text-lg font-semibold text-accent mb-4">{service.price}</p>
                  <Button 
                    variant="default" 
                    className="w-full group-hover:scale-105 transition-transform duration-300"
                    asChild
                  >
                    <a href="tel:+254785325404">
                      Get Started
                    </a>
                  </Button>
                </div>
              </CardContent>

              {/* Decorative Background */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-primary opacity-5 rounded-full transform translate-x-16 -translate-y-16" />
            </Card>
          ))}
        </div>

        {/* Mobile App Integration Section */}
        <div className="mt-16 text-center">
          <Card className="bg-gradient-primary text-primary-foreground p-8">
            <CardHeader>
              <div className="flex justify-center mb-4">
                <Smartphone className="h-12 w-12" />
              </div>
              <CardTitle className="text-2xl md:text-3xl">Pay with M-Pesa</CardTitle>
              <CardDescription className="text-primary-foreground/80 text-lg">
                Convenient payments at your fingertips
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-6 text-primary-foreground/90">
                Pay your internet bills easily using M-Pesa. No need for cash or bank transfers. 
                Just dial, pay, and stay connected.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="accent" size="lg">
                  Learn More
                </Button>
                <Button variant="outline" size="lg" className="bg-white/10 border-white/30 text-white hover:bg-white/20">
                  View Packages
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Services;