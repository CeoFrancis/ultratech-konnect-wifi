import { Link } from "react-router-dom";
import { Wifi, Phone, Mail, MapPin, MessageCircle, Music } from "lucide-react";
import { Button } from "@/components/ui/button";

const Footer = () => {
  return (
    <footer className="bg-gradient-subtle border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-primary">
                <Wifi className="h-5 w-5 text-primary-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold text-primary">UltratechKonnect</span>
                <span className="text-xs text-muted-foreground">Framwaka Ultratech Ltd</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              Fast. Reliable. Local. Your trusted internet service provider in Naivasha, Kenya.
            </p>
            <div className="flex space-x-2">
              {/* WhatsApp */}
              <a
                href="https://wa.me/254785325404"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-green-500 hover:bg-green-600 text-white transition-colors"
              >
                <MessageCircle className="h-4 w-4" />
              </a>
              {/* Facebook */}
              <a
                href="#"
                className="p-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors"
              >
                <span className="h-4 w-4 flex items-center justify-center text-xs font-bold">f</span>
              </a>
              {/* TikTok */}
              <a
                href="#"
                className="p-2 rounded-lg bg-black hover:bg-gray-800 text-white transition-colors"
              >
                <Music className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-foreground">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/packages" className="text-muted-foreground hover:text-primary transition-colors">Internet Packages</Link></li>
              <li><Link to="/reseller" className="text-muted-foreground hover:text-primary transition-colors">Hotspot Reseller Info</Link></li>
              <li><Link to="/support" className="text-muted-foreground hover:text-primary transition-colors">Support</Link></li>
              <li><Link to="/about" className="text-muted-foreground hover:text-primary transition-colors">About Us</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-foreground">Our Services</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Home Wi-Fi Installation</li>
              <li>Business Internet Solutions</li>
              <li>Hotspot Reseller Setup</li>
              <li>Technical Support</li>
              <li>M-Pesa Payment Integration</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-foreground">Contact Us</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-2 text-sm">
                <Phone className="h-4 w-4 text-primary" />
                <a href="tel:+254785325404" className="text-muted-foreground hover:text-primary transition-colors">
                  0785 325 404
                </a>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Mail className="h-4 w-4 text-primary" />
                <a href="mailto:info@ultratechkonnect.com" className="text-muted-foreground hover:text-primary transition-colors">
                  info@ultratechkonnect.com
                </a>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <MapPin className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Naivasha, Kenya</span>
              </div>
            </div>
            <Button variant="whatsapp" size="sm" className="w-full" asChild>
              <a href="https://wa.me/254785325404" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="h-4 w-4 mr-2" />
                WhatsApp Us
              </a>
            </Button>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            © 2024 Framwaka Ultratech Ltd. All rights reserved. | UltratechKonnect - Your Local Internet Solution
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;