import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";

const Testimonials = () => {
  const testimonials = [
    {
      name: "Mary Wanjiku",
      location: "Naivasha Town",
      role: "Small Business Owner",
      content: "UltratechKonnect transformed my business! The internet is fast and reliable. I can now serve customers online and my sales have doubled. The M-Pesa payments make it so convenient.",
      rating: 5,
      avatar: "MW"
    },
    {
      name: "John Kimani",
      location: "Karagita Estate",
      role: "Work From Home",
      content: "Working from home was a nightmare before UltratechKonnect. Now I have stable internet for video calls and my productivity has increased significantly. Great customer service too!",
      rating: 5,
      avatar: "JK"
    },
    {
      name: "Grace Njeri",
      location: "Mai Mahiu",
      role: "Student",
      content: "As a university student, I needed reliable internet for online classes. UltratechKonnect has been amazing - no more dropped connections during important lectures!",
      rating: 5,
      avatar: "GN"
    },
    {
      name: "Peter Mwangi",
      location: "Kongoni",
      role: "Hotspot Reseller",
      content: "The reseller program has been a great source of income. UltratechKonnect provided training and ongoing support. I'm now earning good money serving my community.",
      rating: 5,
      avatar: "PM"
    }
  ];

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            What Our Customers Say
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Don't just take our word for it. Here's what real customers across Naivasha say about UltratechKonnect.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="relative overflow-hidden group hover:shadow-elegant transition-all duration-300 bg-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-accent text-accent" />
                    ))}
                  </div>
                  <Quote className="h-8 w-8 text-primary/20" />
                </div>

                <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                  "{testimonial.content}"
                </p>

                <div className="flex items-center space-x-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-primary text-primary-foreground font-semibold text-sm">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-sm">{testimonial.name}</h4>
                    <p className="text-xs text-muted-foreground">{testimonial.role}</p>
                    <p className="text-xs text-primary">{testimonial.location}</p>
                  </div>
                </div>
              </CardContent>

              {/* Hover Effect */}
              <div className="absolute inset-0 bg-gradient-primary opacity-0 group-hover:opacity-5 transition-opacity duration-300" />
            </Card>
          ))}
        </div>

        {/* Trust Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div className="space-y-2">
            <h3 className="text-3xl md:text-4xl font-bold text-primary">500+</h3>
            <p className="text-sm text-muted-foreground">Happy Customers</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-3xl md:text-4xl font-bold text-primary">99.9%</h3>
            <p className="text-sm text-muted-foreground">Uptime</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-3xl md:text-4xl font-bold text-primary">24/7</h3>
            <p className="text-sm text-muted-foreground">Support</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-3xl md:text-4xl font-bold text-primary">4+</h3>
            <p className="text-sm text-muted-foreground">Years Serving</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;