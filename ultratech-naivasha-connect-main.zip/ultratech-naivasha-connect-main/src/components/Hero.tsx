import { Button } from "@/components/ui/button";
import { Wifi, Zap, MapPin, MessageCircle } from "lucide-react";
import heroImage from "@/assets/hero-internet.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImage} 
          alt="Fast Internet Connection" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 via-primary/70 to-transparent" />
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          <div className="flex items-center space-x-2 mb-6">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent shadow-accent animate-pulse-glow">
              <Wifi className="h-6 w-6 text-accent-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="text-white text-sm font-medium">Framwaka Ultratech Ltd</span>
              <span className="text-white/80 text-xs">Your Local ISP</span>
            </div>
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            Fast. Reliable. 
            <span className="block text-accent">Local.</span>
            <span className="block">Get Connected with</span>
            <span className="block text-accent">UltratechKonnect</span>
          </h1>

          <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl">
            Experience high-speed internet tailored for Naivasha. From home Wi-Fi to business solutions, 
            we deliver reliable connectivity with local support you can trust.
          </p>

          {/* Features */}
          <div className="flex flex-wrap gap-4 mb-8">
            <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-lg px-3 py-2">
              <Zap className="h-4 w-4 text-accent" />
              <span className="text-white text-sm">High-Speed Internet</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-lg px-3 py-2">
              <MapPin className="h-4 w-4 text-accent" />
              <span className="text-white text-sm">Naivasha Local</span>
            </div>
            <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-lg px-3 py-2">
              <MessageCircle className="h-4 w-4 text-accent" />
              <span className="text-white text-sm">24/7 Support</span>
            </div>
          </div>

          {/* Call to Action */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              variant="hero" 
              size="lg" 
              className="animate-float text-lg px-8 py-6"
              asChild
            >
              <a href="tel:+254785325404">
                Get Connected Now
              </a>
            </Button>
            
            <Button 
              variant="outline" 
              size="lg"
              className="bg-white/10 border-white/30 text-white hover:bg-white/20 hover:text-white px-8 py-6"
              asChild
            >
              <a href="https://wa.me/254785325404" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="h-5 w-5 mr-2" />
                WhatsApp Us
              </a>
            </Button>
          </div>

          {/* Trust Badge */}
          <div className="mt-8 inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-lg px-4 py-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-white/90 text-sm">Serving Naivasha since 2020 • 500+ Happy Customers</span>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 right-20 w-32 h-32 bg-accent/20 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-20 right-40 w-24 h-24 bg-primary-glow/30 rounded-full blur-2xl animate-float" style={{ animationDelay: "1s" }} />
    </section>
  );
};

export default Hero;