import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, MapPin, Award, Clock, Heart, Zap, Shield, Target } from "lucide-react";

const About = () => {
  const values = [
    {
      icon: Zap,
      title: "Speed & Reliability",
      description: "We prioritize fast, consistent internet connections that you can depend on for work, education, and entertainment."
    },
    {
      icon: Heart,
      title: "Community First",
      description: "As a local company, we understand Naivasha's unique needs and are committed to serving our community."
    },
    {
      icon: Shield,
      title: "Trust & Transparency",
      description: "We believe in honest pricing, clear communication, and building long-term relationships with our customers."
    },
    {
      icon: Target,
      title: "Customer Success",
      description: "Your satisfaction is our success. We go above and beyond to ensure you have the best internet experience."
    }
  ];

  const milestones = [
    {
      year: "2020",
      title: "Company Founded",
      description: "Framwaka Ultratech Ltd established with a vision to bring reliable internet to Naivasha"
    },
    {
      year: "2021",
      title: "First 100 Customers",
      description: "Reached our first major milestone, serving households and businesses across Naivasha Town"
    },
    {
      year: "2022",
      title: "Network Expansion",
      description: "Extended coverage to Mai Mahiu, Karagita Estate, and surrounding areas"
    },
    {
      year: "2023",
      title: "Reseller Program",
      description: "Launched our hotspot reseller program, empowering locals to start their own internet businesses"
    },
    {
      year: "2024",
      title: "500+ Happy Customers",
      description: "Serving over 500 satisfied customers with 99.9% uptime and 24/7 local support"
    }
  ];

  const team = [
    {
      name: "James Waweru",
      role: "Founder & CEO",
      description: "Passionate about bringing technology to rural areas",
      initials: "JW"
    },
    {
      name: "Grace Njeri", 
      role: "Technical Director",
      description: "15+ years in telecommunications and network infrastructure",
      initials: "GN"
    },
    {
      name: "Samuel Kiprotich",
      role: "Customer Success Manager",
      description: "Ensuring every customer gets the support they deserve",
      initials: "SK"
    },
    {
      name: "Mary Wanjiku",
      role: "Operations Manager", 
      description: "Streamlining processes for better customer experience",
      initials: "MW"
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-hero py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <Badge className="bg-accent text-accent-foreground mb-4">
                About UltratechKonnect
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Connecting Naivasha, One Home at a Time
              </h1>
              <p className="text-lg md:text-xl text-white/90 mb-8">
                We're more than just an internet service provider. We're your neighbors, committed to 
                bringing reliable, fast internet to every corner of Naivasha and beyond.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="accent" size="lg">
                  <a href="tel:+254785325404">Get Connected Today</a>
                </Button>
                <Button variant="outline" size="lg" className="bg-white/10 border-white/30 text-white hover:bg-white/20">
                  <a href="/packages">View Our Packages</a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Our Story */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div>
                  <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
                    Our Story
                  </h2>
                  <p className="text-lg text-muted-foreground mb-6">
                    Founded in 2020 under Framwaka Ultratech Ltd, UltratechKonnect was born from a simple 
                    observation: Naivasha deserved better internet connectivity. Our founder, having experienced 
                    the frustration of unreliable internet firsthand, decided to build a solution.
                  </p>
                  <p className="text-lg text-muted-foreground mb-6">
                    What started as a mission to serve a few households has grown into a comprehensive 
                    internet service provider serving over 500 customers across Naivasha and its surroundings. 
                    We've maintained our commitment to personal service and local support throughout our growth.
                  </p>
                  <p className="text-lg text-muted-foreground">
                    Today, we're not just connecting homes and businesses to the internet – we're connecting 
                    our community to opportunities, education, and the wider world.
                  </p>
                </div>
                <div className="space-y-6">
                  <Card className="border-2 border-primary/20">
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-primary">
                          <Users className="h-6 w-6 text-primary-foreground" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-primary">500+</h4>
                          <p className="text-muted-foreground">Happy Customers</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="border-2 border-accent/20">
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-accent">
                          <MapPin className="h-6 w-6 text-accent-foreground" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-accent">10+</h4>
                          <p className="text-muted-foreground">Areas Covered</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="border-2 border-green-500/20">
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-500">
                          <Clock className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <h4 className="text-xl font-bold text-green-600">99.9%</h4>
                          <p className="text-muted-foreground">Network Uptime</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Our Values */}
        <section className="py-16 bg-gradient-subtle">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Our Values
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  These core values guide everything we do, from how we design our network 
                  to how we serve our customers.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {values.map((value, index) => (
                  <Card key={index} className="text-center hover:shadow-elegant transition-all duration-300">
                    <CardHeader>
                      <div className="flex justify-center mb-4">
                        <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-gradient-primary">
                          <value.icon className="h-8 w-8 text-primary-foreground" />
                        </div>
                      </div>
                      <CardTitle className="text-xl">{value.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">{value.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Timeline */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Our Journey
                </h2>
                <p className="text-lg text-muted-foreground">
                  From humble beginnings to becoming Naivasha's trusted internet provider
                </p>
              </div>

              <div className="space-y-8">
                {milestones.map((milestone, index) => (
                  <Card key={index} className="border-l-4 border-l-primary hover:shadow-elegant transition-all duration-300">
                    <CardContent className="p-6">
                      <div className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-6">
                        <div className="flex-shrink-0">
                          <Badge variant="outline" className="text-lg px-4 py-2 font-bold bg-primary text-primary-foreground">
                            {milestone.year}
                          </Badge>
                        </div>
                        <div className="flex-grow">
                          <h3 className="text-xl font-bold text-foreground mb-2">{milestone.title}</h3>
                          <p className="text-muted-foreground">{milestone.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-16 bg-gradient-subtle">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Meet Our Team
                </h2>
                <p className="text-lg text-muted-foreground">
                  The dedicated professionals working to keep Naivasha connected
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {team.map((member, index) => (
                  <Card key={index} className="text-center hover:shadow-elegant transition-all duration-300">
                    <CardHeader>
                      <div className="flex justify-center mb-4">
                        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-primary text-primary-foreground text-xl font-bold">
                          {member.initials}
                        </div>
                      </div>
                      <CardTitle className="text-lg">{member.name}</CardTitle>
                      <CardDescription className="text-primary font-semibold">{member.role}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">{member.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Mission Statement */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <Card className="bg-gradient-primary text-primary-foreground p-8 text-center max-w-4xl mx-auto">
              <CardHeader>
                <div className="flex justify-center mb-6">
                  <Award className="h-16 w-16" />
                </div>
                <CardTitle className="text-3xl md:text-4xl mb-4">Our Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg md:text-xl text-primary-foreground/90 mb-8">
                  "To bridge the digital divide in Naivasha by providing affordable, reliable, and fast internet 
                  connectivity that empowers individuals, families, and businesses to thrive in the digital age."
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button variant="accent" size="lg" asChild>
                    <a href="/packages">
                      Explore Our Packages
                    </a>
                  </Button>
                  <Button variant="outline" size="lg" className="bg-white/10 border-white/30 text-white hover:bg-white/20" asChild>
                    <a href="/support">
                      Contact Our Team
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default About;