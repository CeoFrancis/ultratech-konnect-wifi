import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Phone, MessageCircle, Mail, Clock, Headphones, BookOpen, Wifi } from "lucide-react";

const Support = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast({
      title: "Support Request Sent!",
      description: "We'll respond to your request within 2 hours during business hours.",
    });
    
    setIsSubmitting(false);
  };

  const faqs = [
    {
      question: "How do I pay my internet bill?",
      answer: "You can pay using M-Pesa by sending money to our Till Number 247681. You can also call us to arrange other payment methods. Remember to include your account number as the reference."
    },
    {
      question: "What should I do if my internet is slow?",
      answer: "First, try restarting your router by unplugging it for 30 seconds. Check if other devices are working. If the problem persists, call our support line at 0785 325 404 for immediate assistance."
    },
    {
      question: "How long does installation take?",
      answer: "Installation typically takes 2-4 hours and is usually completed within 24-48 hours of your request. Our technicians will contact you to schedule a convenient time."
    },
    {
      question: "Do you provide technical support on weekends?",
      answer: "Yes, we provide support 7 days a week. Emergency support is available 24/7 for critical issues. Regular support hours are 8 AM to 8 PM daily."
    },
    {
      question: "Can I upgrade or downgrade my package?",
      answer: "Yes, you can change your package at any time. Changes are typically processed within 24 hours. Contact our support team to discuss your new requirements."
    },
    {
      question: "What areas do you cover in Naivasha?",
      answer: "We cover Naivasha Town, Karagita Estate, Mai Mahiu, Kongoni, and surrounding areas. Contact us to check if your specific location is covered."
    }
  ];

  const supportChannels = [
    {
      icon: Phone,
      title: "Phone Support",
      description: "Speak directly with our technical team",
      contact: "0785 325 404",
      action: "Call Now",
      href: "tel:+254785325404",
      available: "24/7 Emergency | 8 AM - 8 PM Regular",
      color: "border-primary"
    },
    {
      icon: MessageCircle,
      title: "WhatsApp Support", 
      description: "Quick support via WhatsApp",
      contact: "0785 325 404",
      action: "Chat Now",
      href: "https://wa.me/254785325404",
      available: "8 AM - 8 PM Daily",
      color: "border-green-500"
    },
    {
      icon: Mail,
      title: "Email Support",
      description: "Detailed technical queries",
      contact: "support@ultratechkonnect.com",
      action: "Send Email",
      href: "mailto:support@ultratechkonnect.com",
      available: "Response within 4 hours",
      color: "border-accent"
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-hero py-16">
          <div className="container mx-auto px-4 text-center">
            <div className="flex justify-center mb-6">
              <Headphones className="h-16 w-16 text-accent" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Support Center
            </h1>
            <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto">
              Get help when you need it. Our local support team is here to ensure 
              your internet connection stays fast and reliable.
            </p>
          </div>
        </section>

        {/* Quick Support Channels */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Get Help Immediately
              </h2>
              <p className="text-lg text-muted-foreground">
                Choose your preferred way to reach our support team
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {supportChannels.map((channel, index) => (
                <Card key={index} className={`${channel.color} border-2 hover:shadow-elegant transition-all duration-300`}>
                  <CardHeader className="text-center">
                    <div className="flex justify-center mb-4">
                      <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-gradient-primary">
                        <channel.icon className="h-8 w-8 text-primary-foreground" />
                      </div>
                    </div>
                    <CardTitle className="text-xl">{channel.title}</CardTitle>
                    <CardDescription>{channel.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="text-center space-y-4">
                    <div>
                      <p className="font-semibold text-foreground">{channel.contact}</p>
                      <p className="text-sm text-muted-foreground flex items-center justify-center space-x-1">
                        <Clock className="h-3 w-3" />
                        <span>{channel.available}</span>
                      </p>
                    </div>
                    <Button variant="default" className="w-full" asChild>
                      <a href={channel.href} target={channel.href.startsWith('http') ? '_blank' : undefined} rel={channel.href.startsWith('http') ? 'noopener noreferrer' : undefined}>
                        {channel.action}
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Support Request Form */}
        <section className="py-16 bg-gradient-subtle">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Submit a Support Request
                </h2>
                <p className="text-lg text-muted-foreground">
                  Can't reach us right now? Submit a detailed support request and we'll get back to you quickly.
                </p>
              </div>

              <Card className="shadow-elegant">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BookOpen className="h-5 w-5 text-primary" />
                    <span>Technical Support Form</span>
                  </CardTitle>
                  <CardDescription>
                    Provide as much detail as possible to help us resolve your issue quickly
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name *</Label>
                        <Input id="name" required placeholder="Your full name" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number *</Label>
                        <Input id="phone" type="tel" required placeholder="07XX XXX XXX" />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="account">Account Number</Label>
                        <Input id="account" placeholder="Your account number (if known)" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="priority">Issue Priority *</Label>
                        <Select required>
                          <SelectTrigger>
                            <SelectValue placeholder="Select priority level" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low - General inquiry</SelectItem>
                            <SelectItem value="medium">Medium - Service issue</SelectItem>
                            <SelectItem value="high">High - No internet connection</SelectItem>
                            <SelectItem value="urgent">Urgent - Business critical</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="category">Issue Category *</Label>
                      <Select required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select issue category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="connection">Connection Problem</SelectItem>
                          <SelectItem value="speed">Slow Internet Speed</SelectItem>
                          <SelectItem value="billing">Billing Inquiry</SelectItem>
                          <SelectItem value="installation">Installation Request</SelectItem>
                          <SelectItem value="equipment">Equipment Issue</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="subject">Subject *</Label>
                      <Input id="subject" required placeholder="Brief description of your issue" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description">Detailed Description *</Label>
                      <Textarea
                        id="description"
                        required
                        placeholder="Please provide a detailed description of your issue, including any error messages, when it started, and what you've already tried..."
                        rows={6}
                      />
                    </div>

                    <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg">
                      <h4 className="font-semibold text-blue-900 dark:text-blue-300 mb-2">Quick Troubleshooting Tips</h4>
                      <ul className="text-sm text-blue-800 dark:text-blue-400 space-y-1">
                        <li>• Try restarting your router (unplug for 30 seconds)</li>
                        <li>• Check if other devices can connect to the internet</li>
                        <li>• Ensure all cables are properly connected</li>
                        <li>• Clear your browser cache and cookies</li>
                      </ul>
                    </div>

                    <Button type="submit" variant="hero" size="lg" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? "Submitting Request..." : "Submit Support Request"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Frequently Asked Questions
                </h2>
                <p className="text-lg text-muted-foreground">
                  Find quick answers to common questions about our internet services
                </p>
              </div>

              <Card className="shadow-elegant">
                <CardContent className="p-6">
                  <Accordion type="single" collapsible className="w-full">
                    {faqs.map((faq, index) => (
                      <AccordionItem key={index} value={`item-${index}`}>
                        <AccordionTrigger className="text-left">
                          {faq.question}
                        </AccordionTrigger>
                        <AccordionContent className="text-muted-foreground">
                          {faq.answer}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Service Status */}
        <section className="py-16 bg-gradient-subtle">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <Card className="border-2 border-green-500/20 bg-green-50/50 dark:bg-green-950/20">
                <CardHeader className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-green-500">
                      <Wifi className="h-8 w-8 text-white" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl text-green-700 dark:text-green-300">Network Status: All Systems Operational</CardTitle>
                  <CardDescription className="text-green-600 dark:text-green-400">
                    Our network is running smoothly with 99.9% uptime
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <div className="flex items-center justify-center space-x-2 mb-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                        <span className="font-semibold">Naivasha Central</span>
                      </div>
                      <p className="text-sm text-muted-foreground">Operational</p>
                    </div>
                    <div>
                      <div className="flex items-center justify-center space-x-2 mb-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                        <span className="font-semibold">Mai Mahiu</span>
                      </div>
                      <p className="text-sm text-muted-foreground">Operational</p>
                    </div>
                    <div>
                      <div className="flex items-center justify-center space-x-2 mb-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                        <span className="font-semibold">Kongoni Area</span>
                      </div>
                      <p className="text-sm text-muted-foreground">Operational</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mt-6">
                    Last updated: {new Date().toLocaleString()}
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Support;