import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, TrendingUp, Award, Banknote, Headphones, BookOpen, MessageCircle } from "lucide-react";

const Reseller = () => {
  const benefits = [
    {
      icon: TrendingUp,
      title: "Steady Income",
      description: "Earn monthly commissions from every customer you bring to the network"
    },
    {
      icon: Users,
      title: "Growing Market",
      description: "Internet demand is increasing daily - tap into this growing market"
    },
    {
      icon: Award,
      title: "Training & Support",
      description: "Complete training program and ongoing technical support"
    },
    {
      icon: Banknote,
      title: "Low Investment",
      description: "Start your business with minimal upfront costs"
    }
  ];

  const requirements = [
    "Valid Kenyan ID",
    "Business location in our service area",
    "Initial investment of KSh 15,000",
    "Commitment to customer service",
    "Basic computer/smartphone skills"
  ];

  const earnings = [
    { customers: "10-20", monthly: "KSh 8,000 - 15,000", description: "Starter level earnings" },
    { customers: "21-50", monthly: "KSh 16,000 - 35,000", description: "Growing business income" },
    { customers: "51-100", monthly: "KSh 36,000 - 70,000", description: "Established reseller earnings" },
    { customers: "100+", monthly: "KSh 70,000+", description: "Top performer income" }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-hero py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <Badge className="bg-accent text-accent-foreground mb-4">
                Business Opportunity
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Become a UltratechKonnect Reseller
              </h1>
              <p className="text-lg md:text-xl text-white/90 mb-8">
                Start your own internet business and earn monthly income by bringing reliable internet 
                to your community. Join our network of successful resellers across Naivasha.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="accent" size="lg">
                  <a href="tel:+254785325404">Apply Now</a>
                </Button>
                <Button variant="outline" size="lg" className="bg-white/10 border-white/30 text-white hover:bg-white/20">
                  <a href="https://wa.me/254785325404" target="_blank" rel="noopener noreferrer">
                    Learn More on WhatsApp
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Why Become a Reseller?
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Join a growing industry and build a sustainable business serving your community's internet needs.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {benefits.map((benefit, index) => (
                <Card key={index} className="text-center hover:shadow-elegant transition-all duration-300">
                  <CardHeader>
                    <div className="flex justify-center mb-4">
                      <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-gradient-primary">
                        <benefit.icon className="h-8 w-8 text-primary-foreground" />
                      </div>
                    </div>
                    <CardTitle className="text-xl">{benefit.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{benefit.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Earnings Potential */}
        <section className="py-16 bg-gradient-subtle">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Earnings Potential
                </h2>
                <p className="text-lg text-muted-foreground">
                  Your income grows with your customer base. Here's what successful resellers earn:
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {earnings.map((tier, index) => (
                  <Card key={index} className={`relative overflow-hidden ${index === 2 ? 'border-2 border-primary shadow-elegant' : 'border'} hover:shadow-elegant transition-all duration-300`}>
                    {index === 2 && (
                      <div className="absolute top-0 right-0">
                        <Badge className="bg-accent text-accent-foreground rounded-none rounded-bl-lg px-3 py-1">
                          Popular Goal
                        </Badge>
                      </div>
                    )}
                    <CardHeader className="text-center">
                      <CardTitle className="text-primary">{tier.customers} Customers</CardTitle>
                      <CardDescription>{tier.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="text-center">
                      <div className="text-2xl font-bold text-accent mb-2">{tier.monthly}</div>
                      <div className="text-sm text-muted-foreground">per month potential</div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="mt-8 text-center">
                <p className="text-sm text-muted-foreground">
                  * Earnings based on commission structure and customer retention. Individual results may vary.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Requirements & Process */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                {/* Requirements */}
                <div>
                  <h2 className="text-3xl font-bold text-foreground mb-6">
                    Requirements
                  </h2>
                  <Card className="border-2 border-primary/20">
                    <CardContent className="p-6">
                      <ul className="space-y-4">
                        {requirements.map((requirement, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                            <span>{requirement}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                {/* Application Process */}
                <div>
                  <h2 className="text-3xl font-bold text-foreground mb-6">
                    How to Apply
                  </h2>
                  <div className="space-y-4">
                    <Card className="border-l-4 border-l-primary">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-bold">
                            1
                          </div>
                          <div>
                            <h4 className="font-semibold">Contact Us</h4>
                            <p className="text-sm text-muted-foreground">Call or WhatsApp to express interest</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-l-accent">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-accent text-accent-foreground text-sm font-bold">
                            2
                          </div>
                          <div>
                            <h4 className="font-semibold">Interview & Assessment</h4>
                            <p className="text-sm text-muted-foreground">Meet with our team to discuss the opportunity</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-l-green-500">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-500 text-white text-sm font-bold">
                            3
                          </div>
                          <div>
                            <h4 className="font-semibold">Training & Setup</h4>
                            <p className="text-sm text-muted-foreground">Complete training and receive your starter kit</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-l-blue-500">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-500 text-white text-sm font-bold">
                            4
                          </div>
                          <div>
                            <h4 className="font-semibold">Start Selling</h4>
                            <p className="text-sm text-muted-foreground">Begin connecting customers and earning commissions</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Support We Provide */}
        <section className="py-16 bg-gradient-subtle">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Support We Provide
                </h2>
                <p className="text-lg text-muted-foreground">
                  You're not alone in this business. We provide comprehensive support to ensure your success.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <Card className="text-center hover:shadow-elegant transition-all duration-300">
                  <CardHeader>
                    <div className="flex justify-center mb-4">
                      <BookOpen className="h-12 w-12 text-primary" />
                    </div>
                    <CardTitle>Training Program</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-muted-foreground space-y-2">
                      <li>• Technical training</li>
                      <li>• Sales techniques</li>
                      <li>• Customer service</li>
                      <li>• Business management</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="text-center hover:shadow-elegant transition-all duration-300">
                  <CardHeader>
                    <div className="flex justify-center mb-4">
                      <Headphones className="h-12 w-12 text-accent" />
                    </div>
                    <CardTitle>Ongoing Support</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-muted-foreground space-y-2">
                      <li>• Technical helpdesk</li>
                      <li>• Marketing materials</li>
                      <li>• Regular check-ins</li>
                      <li>• Performance reviews</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="text-center hover:shadow-elegant transition-all duration-300">
                  <CardHeader>
                    <div className="flex justify-center mb-4">
                      <MessageCircle className="h-12 w-12 text-green-500" />
                    </div>
                    <CardTitle>Communication</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-muted-foreground space-y-2">
                      <li>• WhatsApp support group</li>
                      <li>• Monthly meetings</li>
                      <li>• Direct line to management</li>
                      <li>• Peer networking</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <Card className="bg-gradient-primary text-primary-foreground p-8 text-center max-w-4xl mx-auto">
              <CardHeader>
                <CardTitle className="text-3xl md:text-4xl mb-4">Ready to Start Your Internet Business?</CardTitle>
                <CardDescription className="text-primary-foreground/80 text-lg">
                  Join our network of successful resellers and start earning from day one. 
                  The internet market is growing - don't miss this opportunity.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button variant="accent" size="lg" asChild>
                    <a href="tel:+254785325404">
                      <Users className="h-5 w-5 mr-2" />
                      Apply Now - Call Us
                    </a>
                  </Button>
                  <Button variant="outline" size="lg" className="bg-white/10 border-white/30 text-white hover:bg-white/20" asChild>
                    <a href="https://wa.me/254785325404" target="_blank" rel="noopener noreferrer">
                      <MessageCircle className="h-5 w-5 mr-2" />
                      WhatsApp Application
                    </a>
                  </Button>
                </div>
                <p className="text-primary-foreground/80 text-sm mt-4">
                  Limited positions available in each area. Apply today to secure your territory.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Reseller;