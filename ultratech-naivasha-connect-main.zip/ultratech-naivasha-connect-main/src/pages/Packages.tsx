import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Wifi, Zap, Users, Star } from "lucide-react";

const Packages = () => {
  const packages = [
    {
      name: "Basic Home",
      speed: "10 Mbps",
      price: "KSh 2,500",
      period: "per month",
      description: "Perfect for small families and light internet usage",
      features: [
        "Up to 10 Mbps download speed",
        "Unlimited data",
        "Free installation",
        "Basic support",
        "M-Pesa payment option"
      ],
      popular: false,
      color: "border-border"
    },
    {
      name: "Family Plus",
      speed: "25 Mbps", 
      price: "KSh 4,000",
      period: "per month",
      description: "Ideal for families with multiple devices and streaming",
      features: [
        "Up to 25 Mbps download speed",
        "Unlimited data",
        "Free installation & router",
        "Priority support",
        "M-Pesa payment option",
        "Free Wi-Fi extender"
      ],
      popular: true,
      color: "border-primary"
    },
    {
      name: "Premium Home",
      speed: "50 Mbps",
      price: "KSh 6,500",
      period: "per month", 
      description: "High-speed internet for power users and home offices",
      features: [
        "Up to 50 Mbps download speed",
        "Unlimited data",
        "Free premium router",
        "24/7 priority support",
        "M-Pesa payment option",
        "Free technical visits"
      ],
      popular: false,
      color: "border-border"
    },
    {
      name: "Business Starter",
      speed: "30 Mbps",
      price: "KSh 8,000",
      period: "per month",
      description: "Reliable internet solution for small businesses",
      features: [
        "Up to 30 Mbps dedicated speed",
        "Unlimited data",
        "Business-grade router",
        "Dedicated support line",
        "Monthly invoicing",
        "99.9% uptime guarantee"
      ],
      popular: false,
      color: "border-accent"
    },
    {
      name: "Business Pro",
      speed: "100 Mbps",
      price: "KSh 15,000",
      period: "per month",
      description: "Enterprise-level connectivity for growing businesses",
      features: [
        "Up to 100 Mbps dedicated speed",
        "Unlimited data",
        "Enterprise router & backup",
        "24/7 dedicated support",
        "Custom billing options",
        "99.9% uptime SLA"
      ],
      popular: false,
      color: "border-accent"
    },
    {
      name: "Corporate",
      speed: "Custom",
      price: "Contact Us",
      period: "for pricing",
      description: "Tailored solutions for large organizations",
      features: [
        "Custom bandwidth allocation",
        "Dedicated fiber connection",
        "Redundancy & failover",
        "On-site technical team",
        "Custom SLA agreements",
        "Load balancing solutions"
      ],
      popular: false,
      color: "border-accent"
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-hero py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Internet Packages
            </h1>
            <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto">
              Choose the perfect internet plan for your needs. All packages include unlimited data, 
              free installation, and our reliable local support.
            </p>
          </div>
        </section>

        {/* Packages Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {packages.map((pkg, index) => (
                <Card key={index} className={`relative overflow-hidden ${pkg.color} ${pkg.popular ? 'border-2 border-primary shadow-elegant' : 'border'} hover:shadow-elegant transition-all duration-300`}>
                  {pkg.popular && (
                    <div className="absolute top-0 right-0">
                      <Badge className="bg-primary text-primary-foreground rounded-none rounded-bl-lg px-3 py-1">
                        <Star className="h-3 w-3 mr-1" />
                        Most Popular
                      </Badge>
                    </div>
                  )}
                  
                  <CardHeader className="text-center">
                    <div className="flex justify-center mb-4">
                      <div className={`flex h-16 w-16 items-center justify-center rounded-xl ${pkg.popular ? 'bg-gradient-primary' : 'bg-gradient-accent'}`}>
                        <Wifi className="h-8 w-8 text-white" />
                      </div>
                    </div>
                    <CardTitle className="text-xl font-bold">{pkg.name}</CardTitle>
                    <CardDescription className="text-muted-foreground">
                      {pkg.description}
                    </CardDescription>
                    <div className="mt-4">
                      <div className="flex items-baseline justify-center space-x-1">
                        <span className="text-3xl font-bold text-primary">{pkg.price}</span>
                        <span className="text-sm text-muted-foreground">/{pkg.period}</span>
                      </div>
                      <div className="flex items-center justify-center space-x-2 mt-2">
                        <Zap className="h-4 w-4 text-accent" />
                        <span className="text-lg font-semibold text-accent">{pkg.speed}</span>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <ul className="space-y-3">
                      {pkg.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start space-x-2">
                          <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <div className="pt-6">
                      <Button 
                        variant={pkg.popular ? "hero" : "default"}
                        className="w-full"
                        asChild
                      >
                        <a href="tel:+254785325404">
                          Choose This Plan
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Additional Information */}
        <section className="py-16 bg-gradient-subtle">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-center text-foreground mb-8">
                Why Choose UltratechKonnect?
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-primary">
                      <Zap className="h-6 w-6 text-primary-foreground" />
                    </div>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Fast Installation</h3>
                  <p className="text-muted-foreground text-sm">Get connected within 24-48 hours of signup</p>
                </div>
                
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-accent">
                      <Users className="h-6 w-6 text-accent-foreground" />
                    </div>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Local Support</h3>
                  <p className="text-muted-foreground text-sm">Dedicated local team for quick issue resolution</p>
                </div>
                
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-primary">
                      <Wifi className="h-6 w-6 text-primary-foreground" />
                    </div>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Reliable Network</h3>
                  <p className="text-muted-foreground text-sm">99.9% uptime with redundant infrastructure</p>
                </div>
              </div>

              <Card className="bg-accent/10 border-accent/20">
                <CardContent className="p-6 text-center">
                  <h3 className="text-xl font-semibold text-accent-foreground mb-4">
                    Need a Custom Package?
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    We can create a tailored internet solution for your specific needs. 
                    Contact us to discuss your requirements.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button variant="accent" asChild>
                      <a href="tel:+254785325404">Call Us Now</a>
                    </Button>
                    <Button variant="outline" asChild>
                      <a href="https://wa.me/254785325404" target="_blank" rel="noopener noreferrer">
                        WhatsApp Us
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Packages;